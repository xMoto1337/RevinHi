RevinHi 3D - STEP / IGES reader
===============================

The files in this folder open STEP (.step, .stp) and IGES (.iges, .igs) files.
They are occt-import-js (https://github.com/kovacsv/occt-import-js), which is
Open CASCADE Technology (https://dev.opencascade.org) compiled to WebAssembly.
Both are licensed under the GNU Lesser General Public License version 2.1
(LICENSE-OCCT.txt, LICENSE-occt-import-js.txt; Open CASCADE adds a small
exception, see LICENSE-OCCT.txt).

RevinHi 3D loads these files only when you open a STEP or IGES file, from this
folder, at run time. They are not built into the app.

Replacing them
--------------
You may replace them with your own build (for example a newer or modified
occt-import-js, built with emscripten from its source code):

  1. Close RevinHi 3D.
  2. Replace occt-import-js.js and occt-import-js.wasm in this folder with your
     build. Keep the same file names. The .js file must define the global
     factory function `occtimportjs` (emscripten MODULARIZE build, as in
     occt-import-js) and the module must have ReadStepFile and ReadIgesFile.
  3. Start RevinHi 3D and open a STEP file.

The source code of the versions shipped here is available at
https://github.com/kovacsv/occt-import-js (tag v0.0.23) and
https://github.com/Open-Cascade-SAS/OCCT.
